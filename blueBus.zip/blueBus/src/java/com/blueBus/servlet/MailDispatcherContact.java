/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.blueBus.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.blueBus.ejb.MailSenderContact;

import java.sql.*;

import javax.ejb.EJB;
import javax.servlet.http.HttpSession;
/**
 *
 * @author Abhipreet
 */
@WebServlet(name = "MailDispatcherContact", urlPatterns = {"/MailDispatcherContact"})
public class MailDispatcherContact extends HttpServlet {

    @EJB
    private MailSenderContact mailSender;
    
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
  
                                
                                
                                   try
                                   {
                                         HttpSession session=request.getSession();
     String dbUrl="jdbc:derby://localhost:1527/blueBus_DB;create=true;user=root;password=root";
                                  Connection con=DriverManager.getConnection(dbUrl);
                                  ResultSet rs;
                                  Statement s;
                                  PreparedStatement ps1;
                            
                                  String name=request.getParameter("name_txt");
                                  String email=request.getParameter("email_id_txt");
                                  String subject=request.getParameter("subject_txt");
                                  String message=request.getParameter("text_txt");
                                  
                                       
                                        Class.forName("org.apache.derby.jdbc.ClientDriver");   
                                     //   String sql="insert into contact values(?,?,?,?)";
                                        
                                        s=con.createStatement();
                                        s.executeUpdate("insert into contact values('"+name+"','"+email+"','"+subject+"','"+message+"')");
                                        //ps1.setString(1,name);
                                        //ps1.setString(2,email);
                                        //ps1.setString(3,subject);
                                        //ps1.setString(4,message);
                                        
                                        //ps1.execute();
                                        
                                
                            
                            
                            
                                   }
                                    
                                
                                   catch(Exception e)
                                   {
                                     e.printStackTrace();
                                   }

    
    String toEmail = request.getParameter("email_id_txt");
    String subject = "Contact Us: Acknowledgement";
    String message = "We have received your queries. We will revert you shortly. Team blueBus.";

    String fromEmail = "bluebus1011@gmail.com";
    String username = "bluebus1011";
    String password = "bluebus@12";
    
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            mailSender.sendEmail(fromEmail, username, password, toEmail, subject, message);
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"logo.jpg\" width=\"32px\" height=\"32px\" />");
            out.println("<head>");
            out.println("<title>Thank You!!</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<center> <h1>Your query has been recorded.</h1> </center> <br> <br>");
             out.println("<form action='index.jsp'>");
            out.println("<center> <input type='submit' value='Home' style='height:66px;width:200px;text-align:center; line-height:20px; font-size:20px; font-weight:100; color:#8b8b8b; border:1px solid #d5d5d5;outline:none;-webkit-border-radius: 1px;-moz-border-radius: 1px;border-radius: 1px;' </center>");
            out.println("</form>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
